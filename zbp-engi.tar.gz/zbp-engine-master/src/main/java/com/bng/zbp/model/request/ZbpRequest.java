package com.bng.zbp.model.request;


public class ZbpRequest {
}
