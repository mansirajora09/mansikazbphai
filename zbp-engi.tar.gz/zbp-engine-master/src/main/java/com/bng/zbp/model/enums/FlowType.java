package com.bng.zbp.model.enums;

/**
 * @author Mansi Rajora
 */
public enum FlowType {
    SCP,JSON;

}
