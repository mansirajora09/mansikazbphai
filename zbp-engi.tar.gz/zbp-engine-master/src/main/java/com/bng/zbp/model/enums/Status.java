package com.bng.zbp.model.enums;

/**
 * @author Mansi Rajora
 */
public enum Status {
	SCHEDULED,RUNNING,STOP,PAUSE,EXPIRED;

}
