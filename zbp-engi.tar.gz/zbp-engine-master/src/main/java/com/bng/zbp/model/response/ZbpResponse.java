package com.bng.zbp.model.response;

public class ZbpResponse {
}
