package com.bng.zbp.request;

public class blackoutDateTime {
	private int[] SUN;
	private int[] MON;
	private int[] TUE;
	private int[] WED;
	private int[] THR;
	private int[] FRI;
	private int[] SAT;
	public int[] getSUN() {
		return SUN;
	}
	public void setSUN(int[] sUN) {
		SUN = sUN;
	}
	public int[] getMON() {
		return MON;
	}
	public void setMON(int[] mON) {
		MON = mON;
	}
	public int[] getTUE() {
		return TUE;
	}
	public void setTUE(int[] tUE) {
		TUE = tUE;
	}
	public int[] getWED() {
		return WED;
	}
	public void setWED(int[] wED) {
		WED = wED;
	}
	public int[] getTHR() {
		return THR;
	}
	public void setTHR(int[] tHR) {
		THR = tHR;
	}
	public int[] getFRI() {
		return FRI;
	}
	public void setFRI(int[] fRI) {
		FRI = fRI;
	}
	public int[] getSAT() {
		return SAT;
	}
	public void setSAT(int[] sAT) {
		SAT = sAT;
	}
	
}
