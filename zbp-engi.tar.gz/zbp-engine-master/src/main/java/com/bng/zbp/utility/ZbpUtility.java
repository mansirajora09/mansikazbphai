package com.bng.zbp.utility;

import org.springframework.stereotype.Service;

@Service
public class ZbpUtility {
}
