package com.bng.zbp.repository;

import org.springframework.stereotype.Repository;

import com.bng.zbp.model.entity.Tags;

/**
 * @Author Mansi Rajora
 */
@Repository
public interface TagRepository extends BaseJpaRepository<Tags, Long> {


    

	

}
