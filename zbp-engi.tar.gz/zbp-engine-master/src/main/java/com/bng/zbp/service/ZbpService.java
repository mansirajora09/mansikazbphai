package com.bng.zbp.service;

public interface ZbpService {
}
