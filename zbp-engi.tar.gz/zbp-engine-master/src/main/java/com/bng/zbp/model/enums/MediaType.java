package com.bng.zbp.model.enums;

/**
 * @author Mansi Rajora
 */
public enum MediaType {
    BANNER,VIDEO,AUDIO;

}
