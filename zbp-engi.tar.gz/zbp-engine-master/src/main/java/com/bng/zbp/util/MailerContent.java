package com.bng.zbp.util;

public class MailerContent {
	
	
	

}
