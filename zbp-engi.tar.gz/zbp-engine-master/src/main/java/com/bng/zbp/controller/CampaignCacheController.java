package com.bng.zbp.controller;


import com.bng.zbp.cache.model.CampaignDummy;
import com.bng.zbp.cache.repository.RedisRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Mansi Rajora
 */
@Controller
@RequestMapping("cache/")
public class CampaignCacheController {

    @Autowired
    private RedisRepository redisRepository;

    @RequestMapping("/keys")
    public @ResponseBody
    Map<Object, Object> keys() {
        return redisRepository.findAllCampaigns();
    }

    @RequestMapping("/values")
    public @ResponseBody
    Map<String, String> findAll() {
        Map<Object, Object> aa = redisRepository.findAllCampaigns();
        Map<String, String> map = new HashMap<String, String>();
        for (Map.Entry<Object, Object> entry : aa.entrySet()) {
            String key = (String) entry.getKey();
            map.put(key, aa.get(key).toString());
        }
        return map;
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public ResponseEntity<String> add(
            @RequestParam String key,
            @RequestParam String value) {

        CampaignDummy campaign = new CampaignDummy(key, value);

        redisRepository.add(campaign);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public ResponseEntity<String> delete(@RequestParam String key) {
        redisRepository.delete(key);
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
