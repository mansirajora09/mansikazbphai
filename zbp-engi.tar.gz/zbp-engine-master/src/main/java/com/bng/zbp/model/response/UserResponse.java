package com.bng.zbp.model.response;

/**
 * @Author Mansi Rajora
 */
public class UserResponse {
	private String response;
	private int value;
	private String reason;
	private String key;
		public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}

	
	


}
