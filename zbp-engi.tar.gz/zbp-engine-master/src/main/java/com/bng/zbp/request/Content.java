package com.bng.zbp.request;

public class Content {
    String sizea =new String("320*50");
    String sieb =new String("300*250");
    String sizec =new String("336*280");
	public String getSizea() {
		return sizea;
	}
	public void setSizea(String sizea) {
		this.sizea = sizea;
	}
	public String getSieb() {
		return sieb;
	}
	public void setSieb(String sieb) {
		this.sieb = sieb;
	}
	public String getSizec() {
		return sizec;
	}
	public void setSizec(String sizec) {
		this.sizec = sizec;
	}


	}
